import pytest

from clinic_app import create_app
from clinic_app.models import db


@pytest.fixture
def app():
    app = create_app()
    app.config.update(
        TESTING=True,
        SQLALCHEMY_DATABASE_URI="sqlite:///:memory:",
        WTF_CSRF_ENABLED=False,
        ENABLE_IP_RESTRICTION=False,
        RATE_LIMIT_MAX_REQUESTS=9999,
    )

    with app.app_context():
        db.create_all()
        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


def test_security_headers_exist(client):
    response = client.get("/auth/login")

    assert response.status_code == 200
    assert response.headers.get("X-Content-Type-Options") == "nosniff"
    assert response.headers.get("X-Frame-Options") == "DENY"
    assert response.headers.get("Referrer-Policy") == "strict-origin-when-cross-origin"


def test_unauthenticated_user_redirected_to_login(client):
    response = client.get("/dashboard")

    assert response.status_code == 302
    assert "/auth/login" in response.headers.get("Location")


def test_404_custom_page(client):
    response = client.get("/route-yang-tidak-ada")

    assert response.status_code == 404